# Documentation

This folder contains wiring material, laboratory manuals, and report templates.

- `wiring/`: hardware wiring and setup resources.
- `manuals/`: experiment manuals for the six control modules.
- `reports/`: LaTeX and PDF report templates.

