#!/usr/bin/env python3
from pathlib import Path
import tempfile
import numpy as np
from rip_td3_sim_test import TD3Model, load_model

rng = np.random.default_rng(2026)
common = dict(
    b0=np.zeros(64, np.float32),
    w1=np.eye(64, dtype=np.float32),
    b1=np.zeros(64, np.float32),
    w2=np.ones((1, 64), np.float32) / 64.0,
    b2=np.zeros(1, np.float32),
    model_pwm_scale=150.0,
    source=Path("synthetic"),
)
legacy = TD3Model(w0=rng.normal(size=(64, 7)).astype(np.float32), **common)
current = TD3Model(w0=rng.normal(size=(64, 8)).astype(np.float32), **common)
assert legacy.source_input_dim == 7 and legacy.w0.shape == (64, 8)
assert current.source_input_dim == 8 and current.w0.shape == (64, 8)
x7 = rng.normal(size=7).astype(np.float32)
assert legacy.predict(x7)[0] == legacy.predict(np.r_[x7, 3.0])[0]
with tempfile.TemporaryDirectory() as directory:
    path = Path(directory) / "legacy.td3_deploy.npz"
    legacy.save_npz(path)
    loaded = load_model(path)
    assert loaded.source_input_dim == 7
    assert np.all(loaded.w0[:, 7] == 0.0)
print("PASS: legacy 7-D and native 8-D TD3 model compatibility")
