# Classical Control

This folder contains the dual-loop PID, LQR, and MPC modules.

Each module follows the same layout:

```text
<module>/
├── simulation/
└── hardware/
    ├── python/
    └── firmware/
```

