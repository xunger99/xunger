# AI-enabled Control Engineering Rotary Inverted Pendulum Lab

This repository provides source code and teaching materials for an AI-enabled control engineering laboratory built around a rotary inverted pendulum platform.

The materials cover six control modules:

- Dual-loop PID control
- Linear quadratic regulator control
- Model predictive control
- Deep Q-network reinforcement learning
- Proximal policy optimization reinforcement learning
- Twin delayed deep deterministic policy gradient reinforcement learning

The repository is organized around the teaching workflow: simulation, hardware deployment, embedded firmware, and laboratory documentation.

## Repository Layout

```text
.
├── docs/
│   ├── wiring/
│   ├── manuals/
│   └── reports/
├── classical_control/
│   ├── dual_loop_pid/
│   ├── lqr/
│   └── mpc/
├── reinforcement_learning/
│   ├── training/
│   └── deployment/
└── ros2/
```

## Modules

### Classical Control

Each classical-control module contains:

- `simulation/`: Python simulation code for the rotary inverted pendulum.
- `hardware/python/`: Python hardware interface and experiment GUI code.
- `hardware/firmware/`: microcontroller firmware used by the hardware experiment.

### Reinforcement Learning

Each reinforcement-learning module contains:

- `training/`: simulation-based training code.
- `deployment/<algorithm>/python/`: simulation test and hardware deployment code.
- `deployment/<algorithm>/firmware/`: firmware used for hardware experiments.

TD3 also includes an extra model-compatibility self-test under `reinforcement_learning/deployment/td3/extra/`.

### ROS 2 Framework Example

`ros2/` contains a minimal ROS 2 framework for selecting LQR, MPC, DQN, PPO,
or TD3 control on the physical platform through a common serial bridge and
visualization panel. It is an integration example, not a replacement for the
algorithm-specific simulation, training, deployment, firmware, or laboratory
manuals elsewhere in this repository.

## Documentation

- `docs/wiring/`: platform wiring and hardware setup material.
- `docs/manuals/`: laboratory manuals for PID, LQR, MPC, DQN, PPO, and TD3.
- `docs/reports/`: LaTeX and PDF report templates.

## Python Environment

Create a Python environment and install the common dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

The reinforcement-learning training packages include local copies of Gymnasium and Stable-Baselines3 source code used by the original laboratory workflow. Heavy numerical packages such as NumPy, PyTorch, Matplotlib, and Pandas should be installed in the active Python environment.

## Hardware Use

Hardware scripts expect the rotary inverted pendulum platform, the matching firmware, and a serial connection to the microcontroller. Check `docs/wiring/` before running hardware experiments.

## License

The release license is pending supervisor approval. See `LICENSE_PENDING.txt`.
