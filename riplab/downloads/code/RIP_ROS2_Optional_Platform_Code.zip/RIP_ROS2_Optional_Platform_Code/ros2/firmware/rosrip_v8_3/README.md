# RIP Multi-Controller Firmware V8.3

This Arduino STM32 sketch provides the firmware side of the optional ROS 2
multi-controller framework.

Keep these files in the same Arduino sketch directory:

- `rosrip_v8_3.ino`: sensor acquisition, 200 Hz control, safety logic, serial
  protocol, and controller-profile selection.
- `rip_models_v81.h`: compiled DQN, swing-DQN, PPO, and TD3 model assets used by
  the selectable profiles.

The firmware exposes LQR, MPC, DQN, PPO, and TD3 profiles. It does not expose a
dual-loop PID profile. Neural model download commands are disabled because the
validated model snapshots are compiled into flash.

## Compile and Upload

1. Open `rosrip_v8_3.ino` in Arduino IDE.
2. Select the course `Nucleo-64` / STM32F446RE target.
3. Select the same upload method and ST-Link interface used by the standalone
   laboratory firmware.
4. Compile and upload.
5. Close Serial Monitor before launching the ROS 2 serial bridge.

The serial baud rate is `921600`. Common commands are:

```text
STATUS
STOP
CONFIG,LQR,100,3110,990
RUN,LQR,100,3110,990
GO,LQR
GO,MPC
GO,DQN
GO,PPO
GO,TD3
```

Stop the current run before selecting another profile. The firmware owns the
real-time loop; ROS 2 is used for switching, configuration, telemetry, and
visualization.

## Safety and Scope

This combined firmware is a framework example. It does not replace the
standalone firmware, training code, simulation tests, hardware panels, or
laboratory manuals for each controller. Verify wiring, sensor calibration,
signs, mechanical clearance, motor direction, and emergency stop before
enabling motion.
