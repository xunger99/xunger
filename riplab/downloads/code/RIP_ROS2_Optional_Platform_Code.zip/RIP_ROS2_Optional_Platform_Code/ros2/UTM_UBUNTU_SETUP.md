# macOS, UTM, Ubuntu 24.04, and ROS 2 Jazzy Setup

This guide creates an Ubuntu environment on a Mac for building and running the
RIP ROS 2 framework. The physical experiment also requires reliable USB serial
access to the STM32.

## 1. Choose the Correct Architecture and UTM Backend

Use an Ubuntu 24.04 image that matches the Mac:

| Mac | Ubuntu image |
| --- | --- |
| Apple Silicon (M1, M2, M3, M4, or later) | ARM64 / AArch64 |
| Intel Mac | AMD64 / x86_64 |

UTM provides two relevant modes:

| Use case | Recommended UTM backend |
| --- | --- |
| Build, inspect, or run ROS 2 without the physical STM32 | Apple Virtualization or QEMU |
| Connect the STM32 directly to Ubuntu through USB | QEMU with USB sharing enabled |

UTM's documented USB sharing is available only with the QEMU backend. A faster
Apple Virtualization Linux VM is suitable for software-only work, but it cannot
directly take ownership of the STM32 USB device through UTM USB sharing.

Official references:

- [UTM installation for macOS](https://docs.getutm.app/installation/macos/)
- [UTM Linux guest support](https://docs.getutm.app/guest-support/linux/)
- [UTM USB sharing](https://docs.getutm.app/guest-support/sharing/usb/)
- [Ubuntu 24.04 alternative downloads](https://ubuntu.com/download/alternative-downloads)

## 2. Create the Ubuntu Virtual Machine

1. Install the current stable UTM release.
2. Download the Ubuntu 24.04 Desktop ISO matching the Mac architecture.
3. For physical hardware access, create a QEMU-backed Linux VM and enable USB
   sharing. Use ARM64 on Apple Silicon and x86_64 on Intel.
4. A practical starting allocation is 4 CPU cores, 8 GB RAM, and a 64 GB disk.
   Reduce this only when the host Mac has limited resources.
5. Attach the Ubuntu ISO, start the VM, and complete the standard Ubuntu
   installation.
6. Update Ubuntu after the first login:

```bash
sudo apt update
sudo apt upgrade -y
```

Install guest integration packages:

```bash
sudo apt install -y spice-vdagent qemu-guest-agent
```

## 3. Configure STM32 USB Access

In the stopped VM's UTM settings, enable USB sharing. USB 3.0 is normally the
appropriate choice for current Ubuntu guests. Start Ubuntu, connect the
STM32/ST-Link USB cable, then attach that USB device from UTM's USB menu.

Inside Ubuntu, verify detection:

```bash
lsusb
ls -l /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
```

Allow the current Ubuntu user to open serial ports:

```bash
sudo usermod -aG dialout "$USER"
```

Log out and back in, or reboot the VM, before testing again. Do not run the ROS
2 serial bridge while Arduino Serial Monitor is open.

> [!NOTE]
> UTM documents limitations in USB reset behavior. If the STM32 does not
> re-enumerate after flashing or reset, detach it from the UTM USB menu,
> reconnect the cable, and attach it again.

## 4. Install ROS 2 Jazzy

ROS 2 Jazzy deb packages target Ubuntu 24.04 on both AMD64 and ARM64. The
following follows the official ROS 2 repository setup.

Set a UTF-8 locale and enable Ubuntu Universe:

```bash
sudo apt update
sudo apt install -y locales software-properties-common curl
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
sudo add-apt-repository universe
```

Install the current ROS apt-source package:

```bash
ROS_APT_SOURCE_VERSION=$(curl -s https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest | grep -F "tag_name" | awk -F'"' '{print $4}')
curl -L -o /tmp/ros2-apt-source.deb "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${ROS_APT_SOURCE_VERSION}/ros2-apt-source_${ROS_APT_SOURCE_VERSION}.$(. /etc/os-release && echo ${UBUNTU_CODENAME:-${VERSION_CODENAME}})_all.deb"
sudo dpkg -i /tmp/ros2-apt-source.deb
```

Install ROS 2, build tools, and this framework's runtime dependencies:

```bash
sudo apt update
sudo apt install -y ros-jazzy-desktop ros-dev-tools git \
  python3-serial python3-numpy python3-matplotlib python3-pyqt5
```

Initialize `rosdep` if this is a new ROS installation:

```bash
sudo rosdep init
rosdep update
```

If `rosdep init` reports that its sources already exist, do not delete them;
continue with `rosdep update`.

Add ROS 2 Jazzy to future Bash sessions once:

```bash
grep -qxF 'source /opt/ros/jazzy/setup.bash' ~/.bashrc || \
  echo 'source /opt/ros/jazzy/setup.bash' >> ~/.bashrc
source /opt/ros/jazzy/setup.bash
```

Official reference:

- [ROS 2 Jazzy Ubuntu installation](https://docs.ros.org/en/jazzy/Installation/Ubuntu-Install-Debs.html)

## 5. Clone and Build the Framework

Clone the repository into Ubuntu's native filesystem. Building directly inside
a macOS shared directory can cause permission or symbolic-link problems.

```bash
cd ~
git clone https://github.com/ZhixiangJu/2026-AI-enabled-Control-Engineering-Rotary-Inverted-Pendulum-.git
cd 2026-AI-enabled-Control-Engineering-Rotary-Inverted-Pendulum-/ros2/rip_ros2_ws
```

Install declared dependencies and build:

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

Check that the packages are visible:

```bash
ros2 pkg list | grep '^rip_'
```

Expected packages are `rip_bringup`, `rip_interfaces`, `rip_manager`,
`rip_serial_bridge`, and `rip_visualizer`.

## 6. Flash the STM32 Firmware

The sketch is under:

```text
ros2/firmware/rosrip_v8_3/
```

Keep `rosrip_v8_3.ino` and `rip_models_v81.h` together. Compile for the course
Nucleo-64 / STM32F446RE target using the same Arduino STM32 core and upload
method as the standalone laboratory firmware.

Flashing can be performed on macOS before attaching the board to Ubuntu, or
inside Ubuntu after USB pass-through is working. Close Arduino IDE Serial
Monitor when finished.

## 7. Launch and Verify

Find the serial device, then launch:

```bash
ls -l /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
cd ~/2026-AI-enabled-Control-Engineering-Rotary-Inverted-Pendulum-/ros2/rip_ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch rip_bringup rip.launch.py port:=/dev/ttyACM0 baud:=921600
```

In a second terminal:

```bash
source /opt/ros/jazzy/setup.bash
source ~/2026-AI-enabled-Control-Engineering-Rotary-Inverted-Pendulum-/ros2/rip_ros2_ws/install/setup.bash
ros2 topic list
ros2 topic echo /rip/state
```

Do not energize the motor merely because telemetry is visible. Complete the
wiring, calibration, sign, PWM-limit, and emergency-stop checks described in
the laboratory manuals before any controlled motion.

## 8. Optional Shared Directory

For QEMU Linux guests, UTM supports VirtFS or SPICE WebDAV sharing. For Apple
Virtualization Linux guests, UTM supports VirtioFS. Shared directories are
useful for transferring files, but keep the active colcon workspace under the
Ubuntu home directory.

See the official [UTM directory sharing guide](https://docs.getutm.app/guest-support/sharing/directory/).
