from setuptools import setup

package_name = 'rip_serial_bridge'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Zhixiang Ju',
    maintainer_email='zhixiangju@users.noreply.github.com',
    description='Serial bridge between ROS 2 topics and RIP STM32 firmware.',
    license='LicenseRef-Pending',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'serial_bridge_node = rip_serial_bridge.serial_bridge_node:main',
        ],
    },
)
