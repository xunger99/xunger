from setuptools import setup
from glob import glob
import os

package_name = 'rip_bringup'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name,
            ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Zhixiang Ju',
    maintainer_email='zhixiangju@users.noreply.github.com',
    description='Bringup launch files for ROS2 rotary inverted pendulum.',
    license='LicenseRef-Pending',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        ],
    },
)
