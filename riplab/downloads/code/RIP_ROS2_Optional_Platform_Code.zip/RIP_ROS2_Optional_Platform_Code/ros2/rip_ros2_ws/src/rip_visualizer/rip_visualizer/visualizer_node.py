#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import math
import os
from collections import deque
from datetime import datetime

import rclpy
from rclpy.node import Node

from std_msgs.msg import String
from rip_interfaces.msg import RipState

from PyQt5 import QtCore, QtWidgets

import numpy as np

from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401


ARM_LENGTH = 0.18
PEND_LENGTH = 0.24

MOTOR_RADIUS = 0.035
MOTOR_HEIGHT = 0.08
ARM_Z = MOTOR_HEIGHT

PEND_TANGENTIAL_SIGN = 1.0


def set_line3d(line, p0, p1):
    line.set_data([p0[0], p1[0]], [p0[1], p1[1]])
    line.set_3d_properties([p0[2], p1[2]])


def set_point3d(point, p):
    point.set_data([p[0]], [p[1]])
    point.set_3d_properties([p[2]])


def rip_points(theta, alpha):
    center = np.array([0.0, 0.0, ARM_Z])

    e_r = np.array([math.cos(theta), math.sin(theta), 0.0])
    e_t = np.array([-math.sin(theta), math.cos(theta), 0.0])
    e_z = np.array([0.0, 0.0, 1.0])

    joint = center + ARM_LENGTH * e_r

    pend_dir = (
        PEND_TANGENTIAL_SIGN * math.sin(alpha) * e_t
        + math.cos(alpha) * e_z
    )

    tip = joint + PEND_LENGTH * pend_dir
    ref_tip = joint + PEND_LENGTH * e_z

    return center, joint, tip, ref_tip, e_t


class RipGroundStation(Node, QtWidgets.QMainWindow):
    def __init__(self):
        Node.__init__(self, "rip_visualizer_node")
        QtWidgets.QMainWindow.__init__(self)

        self.setWindowTitle("RIP Ground Control Station | Rotary Inverted Pendulum")
        self.resize(1100, 700)

        self.manager_pub = self.create_publisher(String, "/rip/manager_cmd", 10)
        self.raw_pub = self.create_publisher(String, "/rip/raw_cmd", 10)

        self.state_sub = self.create_subscription(
            RipState,
            "/rip/state",
            self.state_callback,
            1,
        )

        self.latest_state = None
        self.t0 = None
        self.recording = False
        self.run_t0 = None
        self.last_label_update_t = -1.0

        self.t_buf = deque(maxlen=4000)
        self.theta_buf = deque(maxlen=4000)
        self.alpha_buf = deque(maxlen=4000)
        self.pwm_buf = deque(maxlen=4000)
        self.mode_buf = deque(maxlen=4000)

        self.calib_pref = None
        self.calib_pdown = None
        self.calib_eref = None

        self.build_ui()
        self.build_2d_figure()
        self.build_3d_figure()

        self.spin_timer = QtCore.QTimer(self)
        self.spin_timer.timeout.connect(self.spin_ros_once)
        self.spin_timer.start(5)

        self.plot_timer = QtCore.QTimer(self)
        self.plot_timer.timeout.connect(self.update_active_view)
        self.plot_timer.start(120)

        self.statusBar().showMessage("Ready. Waiting for /rip/state ...")

    # ==========================================================
    # ROS
    # ==========================================================

    def spin_ros_once(self):
        rclpy.spin_once(self, timeout_sec=0.0)

    def state_callback(self, msg):
        now = self.get_clock().now().nanoseconds * 1e-9

        if self.t0 is None:
            self.t0 = now

        t = now - self.t0

        self.latest_state = msg

        # Only record data between GUI GO and GUI STOP.
        # The displayed 3D view still uses latest_state in real time.
        if self.recording:
            if self.run_t0 is None:
                self.run_t0 = now
            tr = now - self.run_t0

            self.t_buf.append(tr)
            self.theta_buf.append(float(msg.theta))
            self.alpha_buf.append(float(msg.alpha))
            self.pwm_buf.append(float(msg.pwm))
            self.mode_buf.append(float(msg.mode))

        if self.last_label_update_t < 0.0 or (t - self.last_label_update_t) >= 0.10:
            self.update_numeric_labels(msg)
            self.last_label_update_t = t

    def publish_manager(self, cmd):
        self.manager_pub.publish(String(data=cmd))
        self.statusBar().showMessage(f"manager_cmd: {cmd}")

    def publish_raw(self, cmd):
        self.raw_pub.publish(String(data=cmd))
        self.statusBar().showMessage(f"raw_cmd: {cmd}")

    # ==========================================================
    # UI
    # ==========================================================

    def build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)

        root = QtWidgets.QHBoxLayout(central)

        left = QtWidgets.QWidget()
        left.setFixedWidth(300)
        left_layout = QtWidgets.QVBoxLayout(left)

        root.addWidget(left)

        # ------------------------------------------------------
        # Controller group
        # ------------------------------------------------------
        group_ctrl = QtWidgets.QGroupBox("Controller")
        form_ctrl = QtWidgets.QFormLayout(group_ctrl)

        self.combo_alg = QtWidgets.QComboBox()
        self.combo_alg.addItems(["LQR", "MPC", "DQN", "PPO", "TD3"])
        self.combo_alg.setCurrentText("MPC")

        self.spin_pwm = QtWidgets.QSpinBox()
        self.spin_pwm.setRange(0, 255)
        self.spin_pwm.setValue(150)

        form_ctrl.addRow("Stable controller:", self.combo_alg)
        form_ctrl.addRow("PWM max:", self.spin_pwm)

        btn_apply = QtWidgets.QPushButton("Apply Config")
        btn_go = QtWidgets.QPushButton("GO")
        btn_stop = QtWidgets.QPushButton("STOP")
        btn_status = QtWidgets.QPushButton("Query STATUS")

        btn_apply.clicked.connect(self.on_apply_config)
        btn_go.clicked.connect(self.on_go)
        btn_stop.clicked.connect(self.on_emergency_stop)
        btn_status.clicked.connect(lambda: self.publish_raw("STATUS"))

        form_ctrl.addRow(btn_apply)

        row_go = QtWidgets.QHBoxLayout()
        row_go.addWidget(btn_go)
        row_go.addWidget(btn_stop)
        form_ctrl.addRow(row_go)

        form_ctrl.addRow(btn_status)

        left_layout.addWidget(group_ctrl)

        # ------------------------------------------------------
        # Calibration group
        # ------------------------------------------------------
        group_cal = QtWidgets.QGroupBox("Potentiometer Calibration")
        cal_layout = QtWidgets.QVBoxLayout(group_cal)

        self.label_pot = QtWidgets.QLabel("pot: --")
        self.label_enc = QtWidgets.QLabel("enc: --")
        self.label_theta = QtWidgets.QLabel("theta: -- rad")
        self.label_alpha = QtWidgets.QLabel("alpha: -- rad")
        self.label_theta_dot = QtWidgets.QLabel("theta_dot: -- rad/s")
        self.label_alpha_dot = QtWidgets.QLabel("alpha_dot: -- rad/s")

        for lab in [
            self.label_pot,
            self.label_enc,
            self.label_theta,
            self.label_alpha,
            self.label_theta_dot,
            self.label_alpha_dot,
        ]:
            cal_layout.addWidget(lab)

        self.label_theta_dot.hide()
        self.label_alpha_dot.hide()

        cal_layout.addSpacing(8)

        btn_cal_up = QtWidgets.QPushButton("1. Hold upright → Calibrate alpha=0 PREF")
        btn_cal_down = QtWidgets.QPushButton("2. Hang down → Calibrate alpha=π PDOWN")
        btn_cal_theta = QtWidgets.QPushButton("3. Current arm → Calibrate theta=0 EREF")

        btn_cal_up.clicked.connect(self.on_calibrate_up)
        btn_cal_down.clicked.connect(self.on_calibrate_down)
        btn_cal_theta.clicked.connect(self.on_calibrate_theta_zero)

        cal_layout.addWidget(btn_cal_up)
        cal_layout.addWidget(btn_cal_down)
        btn_cal_theta.hide()
        # theta encoder calibration removed in compact panel

        self.label_calib = QtWidgets.QLabel("PREF: -- | PDOWN: -- | EREF: --")
        self.label_calib.setWordWrap(True)
        cal_layout.addWidget(self.label_calib)

        left_layout.addWidget(group_cal)

        # ------------------------------------------------------
        # View group
        # ------------------------------------------------------
        group_view = QtWidgets.QGroupBox("Visualization")
        view_layout = QtWidgets.QVBoxLayout(group_view)

        self.combo_view = QtWidgets.QComboBox()
        self.combo_view.addItems([
            "2D views + theta/alpha/pwm curves",
            "3D mechanism view",
        ])
        self.combo_view.currentIndexChanged.connect(self.on_view_changed)

        view_layout.addWidget(self.combo_view)

        btn_clear = QtWidgets.QPushButton("Clear Plot Buffers")
        btn_clear.clicked.connect(self.on_clear_buffers)
        view_layout.addWidget(btn_clear)

        group_view.hide()
        # View selector removed. The panel always shows 3D view.

        # ------------------------------------------------------
        # Save group
        # ------------------------------------------------------
        group_save = QtWidgets.QGroupBox("Save Result Figure")
        save_layout = QtWidgets.QVBoxLayout(group_save)

        self.edit_save_path = QtWidgets.QLineEdit()
        default_dir = os.path.expanduser("~/rip_logs")
        os.makedirs(default_dir, exist_ok=True)
        default_file = os.path.join(default_dir, "rip_result_latest.png")
        self.edit_save_path.setText(default_file)

        btn_browse = QtWidgets.QPushButton("Choose PNG Path")
        btn_save_png = QtWidgets.QPushButton("Save Result Figure PNG")

        btn_browse.clicked.connect(self.on_choose_png_path)
        btn_save_png.clicked.connect(self.on_save_png)

        save_layout.addWidget(self.edit_save_path)
        save_layout.addWidget(btn_browse)
        save_layout.addWidget(btn_save_png)

        group_save.hide()
        # Main save panel removed. Save is available in the result popup after STOP.
        left_layout.addStretch(1)

        # ------------------------------------------------------
        # Right visualization stack
        # ------------------------------------------------------
        self.stack = QtWidgets.QStackedWidget()
        root.addWidget(self.stack, stretch=1)

        self.page_2d = QtWidgets.QWidget()
        self.page_3d = QtWidgets.QWidget()

        self.stack.addWidget(self.page_2d)
        self.stack.addWidget(self.page_3d)
        self.stack.setCurrentIndex(1)

    def update_numeric_labels(self, msg):
        self.label_pot.setText(f"pot: {msg.pot}")
        self.label_enc.setText(f"enc: {msg.enc}")
        self.label_theta.setText(f"theta: {msg.theta:.5f} rad")
        self.label_alpha.setText(f"alpha: {msg.alpha:.5f} rad")
        self.label_theta_dot.setText(f"theta_dot: {msg.theta_dot:.5f} rad/s")
        self.label_alpha_dot.setText(f"alpha_dot: {msg.alpha_dot:.5f} rad/s")

    def update_calib_label(self):
        self.label_calib.setText(
            f"PREF: {self.calib_pref if self.calib_pref is not None else '--'} | "
            f"PDOWN: {self.calib_pdown if self.calib_pdown is not None else '--'}"
        )

    # ==========================================================
    # 2D Figure
    # ==========================================================

    def build_2d_figure(self):
        layout = QtWidgets.QVBoxLayout(self.page_2d)

        self.fig2d = Figure(figsize=(9, 7), tight_layout=True)
        self.canvas2d = FigureCanvas(self.fig2d)
        layout.addWidget(self.canvas2d)

        gs = self.fig2d.add_gridspec(2, 2)

        self.ax_theta_top = self.fig2d.add_subplot(gs[0, 0])
        self.ax_alpha_side = self.fig2d.add_subplot(gs[0, 1])
        self.ax_angle_time = self.fig2d.add_subplot(gs[1, 0])
        self.ax_pwm_time = self.fig2d.add_subplot(gs[1, 1])

        self.fig2d.suptitle("Rotary Inverted Pendulum Monitoring Panel")

        # theta top view
        self.ax_theta_top.set_title("Top View: Rotary Arm Angle θ")
        self.ax_theta_top.set_aspect("equal", adjustable="box")
        self.ax_theta_top.set_xlim(-0.25, 0.25)
        self.ax_theta_top.set_ylim(-0.25, 0.25)
        self.ax_theta_top.set_xlabel("x / m")
        self.ax_theta_top.set_ylabel("y / m")
        circle = plt_circle(0, 0, ARM_LENGTH)
        self.ax_theta_top.add_patch(circle)
        self.theta_arm_line, = self.ax_theta_top.plot([], [], linewidth=4)
        self.theta_joint_dot, = self.ax_theta_top.plot([], [], "o")

        # alpha side view
        self.ax_alpha_side.set_title("Side View: Pendulum Angle α")
        self.ax_alpha_side.set_aspect("equal", adjustable="box")
        self.ax_alpha_side.set_xlim(-0.30, 0.30)
        self.ax_alpha_side.set_ylim(-0.28, 0.30)
        self.ax_alpha_side.set_xlabel("tangential direction / m")
        self.ax_alpha_side.set_ylabel("z / m")
        self.ax_alpha_side.axvline(0.0, linestyle="--", linewidth=1.5)
        self.ax_alpha_side.axhline(0.0, linewidth=0.8)
        self.alpha_ref_line_2d, = self.ax_alpha_side.plot([0, 0], [0, PEND_LENGTH], "--", linewidth=2)
        self.alpha_pend_line_2d, = self.ax_alpha_side.plot([], [], linewidth=4)
        self.alpha_tip_dot_2d, = self.ax_alpha_side.plot([], [], "o")

        # time plots
        self.ax_angle_time.set_title("Angle Response vs Time")
        self.ax_angle_time.set_xlabel("time / s")
        self.ax_angle_time.set_ylabel("angle / rad")
        self.theta_curve, = self.ax_angle_time.plot([], [], label="theta")
        self.alpha_curve, = self.ax_angle_time.plot([], [], label="alpha")
        self.ax_angle_time.legend(loc="upper right")
        self.ax_angle_time.grid(True)

        self.ax_pwm_time.set_title("Control Input vs Time")
        self.ax_pwm_time.set_xlabel("time / s")
        self.ax_pwm_time.set_ylabel("PWM")
        self.pwm_curve, = self.ax_pwm_time.plot([], [], label="pwm")
        self.ax_pwm_time.legend(loc="upper right")
        self.ax_pwm_time.grid(True)

    # ==========================================================
    # 3D Figure: based on your V3 fast logic
    # ==========================================================

    def build_3d_figure(self):
        layout = QtWidgets.QVBoxLayout(self.page_3d)

        self.fig3d = Figure(figsize=(9, 7), tight_layout=True)
        self.canvas3d = FigureCanvas(self.fig3d)
        layout.addWidget(self.canvas3d)

        self.ax3d = self.fig3d.add_subplot(111, projection="3d")

        self.ax3d.set_title("3D View", pad=2)
        self.ax3d.set_xlabel("X / m")
        self.ax3d.set_ylabel("Y / m")
        self.ax3d.set_zlabel("Z / m")

        limit = ARM_LENGTH + PEND_LENGTH + 0.05
        self.ax3d.set_xlim(-limit, limit)
        self.ax3d.set_ylim(-limit, limit)
        self.ax3d.set_zlim(-0.28, 0.38)

        try:
            self.ax3d.set_box_aspect([1, 1, 1])
        except Exception:
            pass

        self.ax3d.view_init(elev=24, azim=-55)

        ang = np.linspace(0, 2 * math.pi, 80)

        self.ax3d.plot(
            MOTOR_RADIUS * np.cos(ang),
            MOTOR_RADIUS * np.sin(ang),
            MOTOR_HEIGHT * np.ones_like(ang),
            linewidth=2.0,
            label="motor cylinder",
        )

        self.ax3d.plot(
            MOTOR_RADIUS * np.cos(ang),
            MOTOR_RADIUS * np.sin(ang),
            np.zeros_like(ang),
            linewidth=1.4,
        )

        for a in np.linspace(0, 2 * math.pi, 8, endpoint=False):
            x = MOTOR_RADIUS * math.cos(a)
            y = MOTOR_RADIUS * math.sin(a)
            self.ax3d.plot([x, x], [y, y], [0.0, MOTOR_HEIGHT], linewidth=1.0)

        self.ax3d.plot(
            ARM_LENGTH * np.cos(ang),
            ARM_LENGTH * np.sin(ang),
            ARM_Z * np.ones_like(ang),
            linestyle="--",
            linewidth=1.0,
            label="arm endpoint circle",
        )

        self.arm_line_3d, = self.ax3d.plot([], [], [], linewidth=6, label="rotary arm")
        self.pend_line_3d, = self.ax3d.plot([], [], [], linewidth=5, label="pendulum")
        self.joint_dot_3d, = self.ax3d.plot([], [], [], marker="o", markersize=8)
        self.tip_dot_3d, = self.ax3d.plot([], [], [], marker="o", markersize=10)

        self.tangent_line_3d, = self.ax3d.plot([], [], [], linestyle=":", linewidth=2, label="local tangent")
        self.alpha_ref_line_3d, = self.ax3d.plot([], [], [], linestyle="--", linewidth=2.5, label="alpha=0 vertical ref")

        self.state_text_3d = self.ax3d.text2D(0.03, 0.89, "", transform=self.ax3d.transAxes, fontsize=11)

        # Legend removed for a cleaner and faster 3D view

    # ==========================================================
    # Commands
    # ==========================================================

    def on_go(self):
        if self.calib_pref is None or self.calib_pdown is None:
            self.statusBar().showMessage(
                "Calibrate upright PREF and downward PDOWN before GO."
            )
            return

        # Start a new experiment record from this GO.
        self.t_buf.clear()
        self.theta_buf.clear()
        self.alpha_buf.clear()
        self.pwm_buf.clear()
        self.mode_buf.clear()

        self.run_t0 = None
        self.recording = True

        algorithm = self.combo_alg.currentText()
        pwm = self.spin_pwm.value()
        command = (
            f"RUN,{algorithm},{pwm},{self.calib_pref},{self.calib_pdown}"
        )
        self.publish_raw(command)
        self.statusBar().showMessage(f"{command} sent. Recording started.")

    def on_emergency_stop(self):
        # 强制急停：同时走 raw_cmd 和 manager_cmd，并重复发送，避免单次消息丢失
        self.publish_raw("STOP")
        self.publish_manager("STOP")
        QtCore.QTimer.singleShot(80, lambda: self.publish_raw("STOP"))
        QtCore.QTimer.singleShot(180, lambda: self.publish_raw("STOP"))
        self.recording = False
        self.statusBar().showMessage("EMERGENCY STOP sent: STOP x3")
        QtCore.QTimer.singleShot(350, self.show_result_plot_popup)

    def on_apply_config(self):
        if self.calib_pref is None or self.calib_pdown is None:
            self.statusBar().showMessage(
                "Calibrate upright PREF and downward PDOWN before Apply Config."
            )
            return

        alg = self.combo_alg.currentText()
        pwm = self.spin_pwm.value()

        self.publish_raw(
            f"CONFIG,{alg},{pwm},{self.calib_pref},{self.calib_pdown}"
        )

    def resend_calibration_if_available(self):
        if self.calib_pref is not None:
            self.publish_raw(f"PREF,{self.calib_pref}")
        if self.calib_pdown is not None:
            self.publish_raw(f"PDOWN,{self.calib_pdown}")
        if self.calib_eref is not None:
            self.publish_raw(f"EREF,{self.calib_eref}")

    def on_calibrate_up(self):
        if self.latest_state is None:
            self.statusBar().showMessage("No /rip/state yet. Cannot calibrate PREF.")
            return

        self.calib_pref = int(self.latest_state.pot)
        self.update_calib_label()
        self.publish_raw(f"PREF,{self.calib_pref}")

    def on_calibrate_down(self):
        if self.latest_state is None:
            self.statusBar().showMessage("No /rip/state yet. Cannot calibrate PDOWN.")
            return

        self.calib_pdown = int(self.latest_state.pot)
        self.update_calib_label()
        self.publish_raw(f"PDOWN,{self.calib_pdown}")

    def on_calibrate_theta_zero(self):
        if self.latest_state is None:
            self.statusBar().showMessage("No /rip/state yet. Cannot calibrate EREF.")
            return

        self.calib_eref = int(self.latest_state.enc)
        self.update_calib_label()
        self.publish_raw(f"EREF,{self.calib_eref}")

    def on_view_changed(self, idx):
        self.stack.setCurrentIndex(idx)
        self.update_active_view()

    def on_clear_buffers(self):
        self.t0 = None
        self.t_buf.clear()
        self.theta_buf.clear()
        self.alpha_buf.clear()
        self.pwm_buf.clear()
        self.mode_buf.clear()
        self.statusBar().showMessage("Plot buffers cleared.")

    def on_choose_png_path(self):
        default_dir = os.path.expanduser("~/rip_logs")
        os.makedirs(default_dir, exist_ok=True)
        name = "rip_result_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".png"
        default_path = os.path.join(default_dir, name)

        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save result figure",
            default_path,
            "PNG Image (*.png)",
        )

        if path:
            if not path.endswith(".png"):
                path += ".png"
            self.edit_save_path.setText(path)

    def on_save_png(self):
        path = self.edit_save_path.text().strip()

        if not path:
            self.statusBar().showMessage("No save path.")
            return

        os.makedirs(os.path.dirname(os.path.expanduser(path)), exist_ok=True)
        path = os.path.expanduser(path)

        fig = Figure(figsize=(10, 7), tight_layout=True)
        ax1 = fig.add_subplot(2, 1, 1)
        ax2 = fig.add_subplot(2, 1, 2)

        fig.suptitle("Rotary Inverted Pendulum Experiment Result")

        t = list(self.t_buf)
        theta = list(self.theta_buf)
        alpha = list(self.alpha_buf)
        pwm = list(self.pwm_buf)

        ax1.set_title("Angle Response vs Time")
        ax1.plot(t, theta, label="theta / rad")
        ax1.plot(t, alpha, label="alpha / rad")
        ax1.set_xlabel("time / s")
        ax1.set_ylabel("angle / rad")
        ax1.grid(True)
        ax1.legend(loc="upper right")

        ax2.set_title("Control Input vs Time")
        ax2.plot(t, pwm, label="PWM")
        ax2.set_xlabel("time / s")
        ax2.set_ylabel("PWM")
        ax2.grid(True)
        ax2.legend(loc="upper right")

        fig.savefig(path, dpi=160)
        self.statusBar().showMessage(f"Saved PNG: {path}")

    def show_result_plot_popup(self):
        if len(self.t_buf) < 2:
            self.statusBar().showMessage("No enough GO-to-STOP data to plot.")
            return

        dialog = QtWidgets.QDialog(self)
        dialog.setWindowTitle("RIP Experiment Result | GO-to-STOP Response")
        dialog.resize(1050, 780)

        layout = QtWidgets.QVBoxLayout(dialog)

        fig = Figure(figsize=(10.5, 7.6), tight_layout=True)
        canvas = FigureCanvas(fig)
        layout.addWidget(canvas)

        # Paper-style plotting parameters.
        fig.patch.set_facecolor("white")

        axs = fig.subplots(2, 2)
        ax_alpha = axs[0, 0]
        ax_theta = axs[0, 1]
        ax_pwm = axs[1, 0]
        ax_hist = axs[1, 1]

        t = np.asarray(list(self.t_buf), dtype=float)
        theta = np.asarray(list(self.theta_buf), dtype=float)
        alpha = np.asarray(list(self.alpha_buf), dtype=float)
        pwm = np.asarray(list(self.pwm_buf), dtype=float)

        # Make sure time starts exactly from zero.
        if len(t) > 0:
            t = t - t[0]

        alpha_abs = np.abs(alpha)
        pwm_abs = np.abs(pwm)

        alpha_abs_mean = float(np.mean(alpha_abs)) if len(alpha_abs) else 0.0
        alpha_abs_std = float(np.std(alpha_abs)) if len(alpha_abs) else 0.0

        pwm_abs_mean = float(np.mean(pwm_abs)) if len(pwm_abs) else 0.0
        pwm_abs_std = float(np.std(pwm_abs)) if len(pwm_abs) else 0.0

        fig.suptitle(
            "Rotary Inverted Pendulum Experimental Response",
            fontsize=15,
            fontweight="bold",
        )

        # ------------------------------------------------------
        # alpha(t)
        # ------------------------------------------------------
        ax_alpha.plot(t, alpha, linewidth=1.8, label=r"$\alpha$")
        ax_alpha.axhline(0.0, linewidth=1.0, linestyle="--")
        ax_alpha.set_title(r"Pendulum Angle $\alpha(t)$", fontsize=12, fontweight="bold")
        ax_alpha.set_xlabel("Time / s")
        ax_alpha.set_ylabel(r"$\alpha$ / rad")
        ax_alpha.grid(True, linestyle="--", linewidth=0.6, alpha=0.55)
        ax_alpha.legend(loc="lower right", frameon=True)

        alpha_text = (
            r"$\mathrm{mean}(|\alpha|)$" + f" = {alpha_abs_mean:.4f} rad\n"
            r"$\mathrm{std}(|\alpha|)$" + f" = {alpha_abs_std:.4f} rad"
        )
        ax_alpha.text(
            0.98,
            0.96,
            alpha_text,
            transform=ax_alpha.transAxes,
            ha="right",
            va="top",
            fontsize=10,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="white", alpha=0.85, edgecolor="0.35"),
        )

        # ------------------------------------------------------
        # theta(t)
        # ------------------------------------------------------
        ax_theta.plot(t, theta, linewidth=1.8, label=r"$\theta$")
        ax_theta.axhline(0.0, linewidth=1.0, linestyle="--")
        ax_theta.set_title(r"Rotary Arm Angle $\theta(t)$", fontsize=12, fontweight="bold")
        ax_theta.set_xlabel("Time / s")
        ax_theta.set_ylabel(r"$\theta$ / rad")
        ax_theta.grid(True, linestyle="--", linewidth=0.6, alpha=0.55)
        ax_theta.legend(loc="upper right", frameon=True)

        # ------------------------------------------------------
        # PWM(t)
        # ------------------------------------------------------
        ax_pwm.plot(t, pwm, linewidth=1.5, label="PWM")
        ax_pwm.axhline(0.0, linewidth=1.0, linestyle="--")
        ax_pwm.set_title("Control Input PWM(t)", fontsize=12, fontweight="bold")
        ax_pwm.set_xlabel("Time / s")
        ax_pwm.set_ylabel("PWM")
        ax_pwm.set_ylim(-270, 270)
        ax_pwm.grid(True, linestyle="--", linewidth=0.6, alpha=0.55)
        ax_pwm.legend(loc="lower right", frameon=True)

        pwm_text = (
            r"$\mathrm{mean}(|PWM|)$" + f" = {pwm_abs_mean:.2f}\n"
            r"$\mathrm{std}(|PWM|)$" + f" = {pwm_abs_std:.2f}"
        )
        ax_pwm.text(
            0.98,
            0.96,
            pwm_text,
            transform=ax_pwm.transAxes,
            ha="right",
            va="top",
            fontsize=10,
            bbox=dict(boxstyle="round,pad=0.35", facecolor="white", alpha=0.85, edgecolor="0.35"),
        )

        # ------------------------------------------------------
        # PWM distribution
        # ------------------------------------------------------
        bins = np.arange(-255, 256 + 1, 15)
        ax_hist.hist(pwm, bins=bins, edgecolor="black", linewidth=0.45)
        ax_hist.axvline(0.0, linewidth=1.0, linestyle="--")
        ax_hist.set_xlim(-255, 255)
        ax_hist.set_title("PWM Distribution", fontsize=12, fontweight="bold")
        ax_hist.set_xlabel("PWM")
        ax_hist.set_ylabel("Count")
        ax_hist.grid(True, linestyle="--", linewidth=0.6, alpha=0.55)

        # Common x limits for time-domain plots.
        if len(t) > 0:
            xmin = 0.0
            xmax = max(float(t[-1]), 0.1)
            for ax in [ax_alpha, ax_theta, ax_pwm]:
                ax.set_xlim(xmin, xmax)

        # Cleaner spines.
        for ax in [ax_alpha, ax_theta, ax_pwm, ax_hist]:
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)
            ax.tick_params(direction="in", length=4, width=0.8)

        canvas.draw_idle()

        row = QtWidgets.QHBoxLayout()
        layout.addLayout(row)

        path_edit = QtWidgets.QLineEdit()
        default_dir = os.path.expanduser("~/rip_logs")
        os.makedirs(default_dir, exist_ok=True)
        default_name = "rip_result_go_to_stop_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".png"
        default_path = os.path.join(default_dir, default_name)
        path_edit.setText(default_path)

        btn_choose = QtWidgets.QPushButton("Choose Path")
        btn_save = QtWidgets.QPushButton("Save PNG")
        btn_close = QtWidgets.QPushButton("Close")

        row.addWidget(path_edit, stretch=1)
        row.addWidget(btn_choose)
        row.addWidget(btn_save)
        row.addWidget(btn_close)

        def choose_path():
            path, _ = QtWidgets.QFileDialog.getSaveFileName(
                dialog,
                "Save GO-to-STOP result figure",
                path_edit.text(),
                "PNG Image (*.png)",
            )
            if path:
                if not path.endswith(".png"):
                    path += ".png"
                path_edit.setText(path)

        def save_png():
            path = os.path.expanduser(path_edit.text().strip())
            if not path:
                return
            if not path.endswith(".png"):
                path += ".png"
                path_edit.setText(path)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            fig.savefig(path, dpi=300, bbox_inches="tight")
            self.statusBar().showMessage(f"Saved GO-to-STOP result figure: {path}")

        btn_choose.clicked.connect(choose_path)
        btn_save.clicked.connect(save_png)
        btn_close.clicked.connect(dialog.close)

        dialog.exec_()

    # ==========================================================
    # Update plots
    # ==========================================================

    def update_active_view(self):
        if self.latest_state is None:
            return

        self.update_3d_view()

    def update_2d_view(self):
        msg = self.latest_state

        theta = float(msg.theta)
        alpha = float(msg.alpha)

        # theta top view
        joint_x = ARM_LENGTH * math.cos(theta)
        joint_y = ARM_LENGTH * math.sin(theta)

        self.theta_arm_line.set_data([0.0, joint_x], [0.0, joint_y])
        self.theta_joint_dot.set_data([joint_x], [joint_y])

        # alpha side view: horizontal axis = local tangent direction
        x_tip = PEND_TANGENTIAL_SIGN * PEND_LENGTH * math.sin(alpha)
        z_tip = PEND_LENGTH * math.cos(alpha)

        self.alpha_pend_line_2d.set_data([0.0, x_tip], [0.0, z_tip])
        self.alpha_tip_dot_2d.set_data([x_tip], [z_tip])

        # curves
        t = list(self.t_buf)
        theta_arr = list(self.theta_buf)
        alpha_arr = list(self.alpha_buf)
        pwm_arr = list(self.pwm_buf)

        self.theta_curve.set_data(t, theta_arr)
        self.alpha_curve.set_data(t, alpha_arr)
        self.pwm_curve.set_data(t, pwm_arr)

        if len(t) > 2:
            xmin = max(0.0, t[-1] - 30.0)
            xmax = max(5.0, t[-1])
            self.ax_angle_time.set_xlim(xmin, xmax)
            self.ax_pwm_time.set_xlim(xmin, xmax)

            vals = theta_arr[-800:] + alpha_arr[-800:]
            if vals:
                vmin = min(vals)
                vmax = max(vals)
                if abs(vmax - vmin) < 0.1:
                    vmin -= 0.1
                    vmax += 0.1
                self.ax_angle_time.set_ylim(vmin - 0.1, vmax + 0.1)

            if pwm_arr:
                pmin = min(pwm_arr[-800:])
                pmax = max(pwm_arr[-800:])
                if abs(pmax - pmin) < 10:
                    pmin -= 10
                    pmax += 10
                self.ax_pwm_time.set_ylim(pmin - 10, pmax + 10)

        self.canvas2d.draw_idle()

    def update_3d_view(self):
        msg = self.latest_state

        theta = float(msg.theta)
        alpha = float(msg.alpha)

        center, joint, tip, ref_tip, e_t = rip_points(theta, alpha)

        set_line3d(self.arm_line_3d, center, joint)
        set_line3d(self.pend_line_3d, joint, tip)
        set_point3d(self.joint_dot_3d, joint)
        set_point3d(self.tip_dot_3d, tip)

        tangent_half = 0.08
        set_line3d(self.tangent_line_3d, joint - tangent_half * e_t, joint + tangent_half * e_t)

        set_line3d(self.alpha_ref_line_3d, joint, ref_tip)

        self.state_text_3d.set_text(
            f"alpha = {alpha: .3f} rad\n"
            f"theta = {theta: .3f} rad\n"
            f"pwm = {msg.pwm}"
        )

        self.canvas3d.draw()


def plt_circle(x, y, r):
    import matplotlib.patches as patches
    return patches.Circle((x, y), r, fill=False, linestyle="--", linewidth=1.0)


def main(args=None):
    rclpy.init(args=args)

    app = QtWidgets.QApplication([])

    window = RipGroundStation()
    window.show()

    ret = app.exec_()

    window.destroy_node()
    rclpy.shutdown()

    return ret


if __name__ == "__main__":
    main()
