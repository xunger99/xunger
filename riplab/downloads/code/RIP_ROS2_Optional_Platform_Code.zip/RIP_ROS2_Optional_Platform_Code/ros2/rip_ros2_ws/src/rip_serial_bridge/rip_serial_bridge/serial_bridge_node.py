import time
import glob
import serial

import rclpy
from rclpy.node import Node

from rip_interfaces.msg import RipState, RipCommand
from std_msgs.msg import String


DEFAULT_BAUD = 921600


def find_port_auto():
    cands = []
    cands += sorted(glob.glob("/dev/ttyACM*"))
    cands += sorted(glob.glob("/dev/ttyUSB*"))
    cands = list(dict.fromkeys(cands))
    if not cands:
        return ""
    return cands[0]


def to_int(x, default=0):
    try:
        return int(float(x))
    except Exception:
        return default


def to_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


class RipSerialBridge(Node):
    def __init__(self):
        super().__init__("rip_serial_bridge")

        self.declare_parameter("port", "")
        self.declare_parameter("baud", DEFAULT_BAUD)

        port = self.get_parameter("port").get_parameter_value().string_value
        baud = self.get_parameter("baud").get_parameter_value().integer_value

        if not port:
            port = find_port_auto()

        if not port:
            raise RuntimeError("No serial port found. Check /dev/ttyACM* or /dev/ttyUSB*.")

        self.get_logger().info(f"Opening serial port: {port}, baud={baud}")

        # 非阻塞串口。不要用 0.001 的 readline timeout，容易读到半行。
        self.ser = serial.Serial(port, baud, timeout=0)
        time.sleep(0.2)
        self.ser.reset_input_buffer()
        self.ser.reset_output_buffer()

        self.rx_buffer = bytearray()
        self.bad_log_count = 0

        self.state_pub = self.create_publisher(RipState, "/rip/state", 10)
        self.cmd_sub = self.create_subscription(
            RipCommand,
            "/rip/cmd",
            self.cmd_callback,
            10
        )

        self.raw_cmd_sub = self.create_subscription(
            String,
            "/rip/raw_cmd",
            self.raw_cmd_callback,
            10
        )

        self.last_enable = False

        self.timer = self.create_timer(0.001, self.read_serial_available)

        self.get_logger().info("RIP serial bridge started.")
        self.get_logger().info("Waiting for STM32 LOG lines...")

    def cmd_callback(self, msg: RipCommand):
        if msg.emergency_stop:
            self.send_stop("Emergency stop")
            return

        if msg.enable and not self.last_enable:
            try:
                self.ser.write(b"GO\n")
                self.ser.flush()
                self.last_enable = True
                self.get_logger().info("Sent GO")
            except Exception as e:
                self.get_logger().error(f"Failed to send GO: {e}")
            return

        if (not msg.enable) and self.last_enable:
            self.send_stop("Disable command")
            return

    def send_stop(self, reason):
        try:
            self.ser.write(b"S\n")
            self.ser.flush()
        except Exception as e:
            self.get_logger().error(f"Failed to send S: {e}")
        self.last_enable = False
        self.get_logger().warn(f"{reason}: sent S")

    def raw_cmd_callback(self, msg: String):
        data = msg.data.strip()
        if not data:
            return

        if not data.endswith("\n"):
            data += "\n"

        try:
            self.ser.write(data.encode("ascii", errors="ignore"))
            self.ser.flush()
            self.get_logger().info(f"Sent raw command: {msg.data.strip()}")
        except Exception as e:
            self.get_logger().error(f"Failed to send raw command: {e}")


    def read_serial_available(self):
        try:
            n = self.ser.in_waiting
            if n <= 0:
                return
            data = self.ser.read(n)
        except Exception as e:
            self.get_logger().error(f"Serial read error: {e}")
            return

        if not data:
            return

        self.rx_buffer.extend(data)

        # 防止异常情况下 buffer 无限增长
        if len(self.rx_buffer) > 8192:
            self.get_logger().warn("RX buffer too large, clearing it.")
            self.rx_buffer.clear()
            return

        while b"\n" in self.rx_buffer:
            idx = self.rx_buffer.index(b"\n")
            raw_line = self.rx_buffer[:idx]
            del self.rx_buffer[:idx + 1]

            line = raw_line.decode(errors="ignore").strip()
            if line:
                self.handle_line(line)

    def handle_line(self, line):
        if "[ARMED]" in line:
            self.get_logger().info(line)
            return

        if line.startswith("[") or line.startswith("===") or line.startswith("COMMANDS") or line.startswith("CALIBRATION"):
            self.get_logger().info(line)
            return

        if line.startswith("LOG_HEADER"):
            self.get_logger().info(line)
            return

        if not line.startswith("LOG,"):
            return

        parts = line.split(",")[1:]

        msg = self.parse_log(parts, line)
        if msg is None:
            return

        self.state_pub.publish(msg)

        if msg.fallen:
            self.send_stop("Fallen detected")

    def parse_log(self, parts, line):
        msg = RipState()
        msg.stamp = self.get_clock().now().to_msg()

        # Current V8.3 format:
        # step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,mode,
        # stable_alg,pwm,u_alg,pot,enc,theta,alpha,theta_dot,alpha_dot
        #
        # Also accept the two older formats used during framework development.
        #
        # 18字段旧格式：
        # step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,mode,
        # pwm,u_rl,u_lqr,u_mix,pot,enc,theta,alpha,theta_dot,alpha_dot
        #
        # 16字段简化格式：
        # step,tick_dt_us,lat_total_us,lat_compute_us,armed,brake,fallen,mode,
        # pwm,u_lqr,pot,enc,theta,alpha,theta_dot,alpha_dot

        if len(parts) == 17:
            msg.step = to_int(parts[0])
            msg.tick_dt_us = to_int(parts[1])
            msg.lat_total_us = to_int(parts[2])
            msg.lat_compute_us = to_int(parts[3])

            msg.armed = bool(to_int(parts[4]))
            msg.brake = bool(to_int(parts[5]))
            msg.fallen = bool(to_int(parts[6]))

            msg.mode = to_int(parts[7])
            msg.stable_alg = to_int(parts[8])
            msg.pwm = to_int(parts[9])
            msg.u_alg = to_float(parts[10])

            msg.pot = to_int(parts[11])
            msg.enc = to_int(parts[12])

            msg.theta = to_float(parts[13])
            msg.alpha = to_float(parts[14])
            msg.theta_dot = to_float(parts[15])
            msg.alpha_dot = to_float(parts[16])

            return msg

        if len(parts) == 18:
            msg.step = to_int(parts[0])
            msg.tick_dt_us = to_int(parts[1])
            msg.lat_total_us = to_int(parts[2])
            msg.lat_compute_us = to_int(parts[3])

            msg.armed = bool(to_int(parts[4]))
            msg.brake = bool(to_int(parts[5]))
            msg.fallen = bool(to_int(parts[6]))

            msg.mode = to_int(parts[7])
            msg.stable_alg = 0
            msg.pwm = to_int(parts[8])
            msg.u_alg = to_float(parts[11])

            msg.pot = to_int(parts[12])
            msg.enc = to_int(parts[13])

            msg.theta = to_float(parts[14])
            msg.alpha = to_float(parts[15])
            msg.theta_dot = to_float(parts[16])
            msg.alpha_dot = to_float(parts[17])

            return msg

        if len(parts) == 16:
            msg.step = to_int(parts[0])
            msg.tick_dt_us = to_int(parts[1])
            msg.lat_total_us = to_int(parts[2])
            msg.lat_compute_us = to_int(parts[3])

            msg.armed = bool(to_int(parts[4]))
            msg.brake = bool(to_int(parts[5]))
            msg.fallen = bool(to_int(parts[6]))

            msg.mode = to_int(parts[7])
            msg.stable_alg = 0
            msg.pwm = to_int(parts[8])
            msg.u_alg = to_float(parts[9])

            msg.pot = to_int(parts[10])
            msg.enc = to_int(parts[11])

            msg.theta = to_float(parts[12])
            msg.alpha = to_float(parts[13])
            msg.theta_dot = to_float(parts[14])
            msg.alpha_dot = to_float(parts[15])

            return msg

        self.bad_log_count += 1
        if self.bad_log_count <= 10 or self.bad_log_count % 50 == 0:
            self.get_logger().warn(f"Bad LOG length={len(parts)} line={line}")
        return None


def main(args=None):
    rclpy.init(args=args)
    node = RipSerialBridge()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().warn("Ctrl+C received. Sending S.")
        try:
            node.ser.write(b"S\n")
            node.ser.flush()
        except Exception:
            pass
    finally:
        try:
            node.ser.close()
        except Exception:
            pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
