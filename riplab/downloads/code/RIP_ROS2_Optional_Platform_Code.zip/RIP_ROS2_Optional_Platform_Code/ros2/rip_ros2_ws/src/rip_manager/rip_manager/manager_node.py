#!/usr/bin/env python3

import os
import re
from pathlib import Path
from collections import deque

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


def expand_path(p):
    return str(Path(os.path.expanduser(p)).resolve())


def parse_numbers(text):
    pat = r"[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?f?"
    vals = []
    for m in re.findall(pat, text):
        if m.endswith("f") or m.endswith("F"):
            m = m[:-1]
        vals.append(float(m))
    return vals


def extract_c_array(text, name):
    pattern = (
        r"static\s+const\s+(?:float|int16_t|int|uint8_t)\s+"
        + re.escape(name)
        + r"\s*(?:\[[^\]]*\])+\s*=\s*\{(.*?)\};"
    )
    m = re.search(pattern, text, flags=re.S)
    if not m:
        return None
    return parse_numbers(m.group(1))


def extract_define_int(text, name, default=None):
    m = re.search(r"#define\s+" + re.escape(name) + r"\s+([0-9]+)", text)
    if not m:
        return default
    return int(m.group(1))


def extract_define_float(text, name, default=None):
    m = re.search(
        r"#define\s+" + re.escape(name) + r"\s+([-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][-+]?\d+)?f?)",
        text,
    )
    if not m:
        return default
    s = m.group(1)
    if s.endswith("f") or s.endswith("F"):
        s = s[:-1]
    return float(s)


def first_existing_array(text, names):
    for n in names:
        v = extract_c_array(text, n)
        if v is not None:
            return n, v
    return None, None


class HeaderNetwork:
    def __init__(self, net_type, obs_dim, h1, h2, out_dim, activation, pwm_limit,
                 W0, B0, W1, B1, W2, B2, actions=None):
        self.net_type = net_type
        self.obs_dim = obs_dim
        self.h1 = h1
        self.h2 = h2
        self.out_dim = out_dim
        self.activation = activation
        self.pwm_limit = pwm_limit
        self.W0 = W0
        self.B0 = B0
        self.W1 = W1
        self.B1 = B1
        self.W2 = W2
        self.B2 = B2
        self.actions = actions or []


def load_header_network(path, net_type):
    path = expand_path(path)
    text = Path(path).read_text()
    net_type = net_type.upper()

    if net_type == "DQN":
        obs_dim = extract_define_int(text, "DQN_STATE_DIM", 6)
        h1 = extract_define_int(text, "DQN_H1", 64)
        h2 = extract_define_int(text, "DQN_H2", 64)
        out_dim = extract_define_int(text, "DQN_ACT_DIM", 10)
        activation = "RELU"
        pwm_limit = 150.0

        # 兼容 DQN_W1/DQN_b1/DQN_W2/DQN_b2/DQN_W3/DQN_b3 以及 DQN_W0/DQN_B0 格式
        if extract_c_array(text, "DQN_W0") is not None:
            _, W0 = first_existing_array(text, ["DQN_W0"])
            _, B0 = first_existing_array(text, ["DQN_B0", "DQN_b0"])
            _, W1 = first_existing_array(text, ["DQN_W1"])
            _, B1 = first_existing_array(text, ["DQN_B1", "DQN_b1"])
            _, W2 = first_existing_array(text, ["DQN_W2"])
            _, B2 = first_existing_array(text, ["DQN_B2", "DQN_b2"])
        else:
            _, W0 = first_existing_array(text, ["DQN_W1"])
            _, B0 = first_existing_array(text, ["DQN_b1", "DQN_B1"])
            _, W1 = first_existing_array(text, ["DQN_W2"])
            _, B1 = first_existing_array(text, ["DQN_b2", "DQN_B2"])
            _, W2 = first_existing_array(text, ["DQN_W3"])
            _, B2 = first_existing_array(text, ["DQN_b3", "DQN_B3"])

        _, actions = first_existing_array(text, ["DQN_ACTIONS"])
        if actions is None:
            actions = [-150, -120, -90, -60, -30, 30, 60, 90, 120, 150]

    elif net_type == "PPO":
        obs_dim = extract_define_int(text, "PPO_OBS_DIM", 6)
        h1 = extract_define_int(text, "PPO_L0_OUT", 64)
        h2 = extract_define_int(text, "PPO_L1_OUT", 64)
        out_dim = extract_define_int(text, "PPO_ACT_DIM", 1)
        activation = "TANH"
        pwm_limit = extract_define_float(text, "PPO_CONTINUOUS_PWM_LIMIT", 150.0)

        _, W0 = first_existing_array(text, ["PPO_W0"])
        _, B0 = first_existing_array(text, ["PPO_B0"])
        _, W1 = first_existing_array(text, ["PPO_W1"])
        _, B1 = first_existing_array(text, ["PPO_B1"])
        _, W2 = first_existing_array(text, ["PPO_W2"])
        _, B2 = first_existing_array(text, ["PPO_B2"])
        actions = []

    elif net_type == "TD3":
        obs_dim = extract_define_int(text, "TD3_OBS_DIM", 7)
        h1 = extract_define_int(text, "TD3_L0_OUT", 64)
        h2 = extract_define_int(text, "TD3_L1_OUT", 64)
        out_dim = extract_define_int(text, "TD3_ACT_DIM", 1)
        activation = "RELU"
        pwm_limit = extract_define_float(text, "TD3_CONTINUOUS_PWM_LIMIT", 150.0)

        _, W0 = first_existing_array(text, ["TD3_W0"])
        _, B0 = first_existing_array(text, ["TD3_B0"])
        _, W1 = first_existing_array(text, ["TD3_W1"])
        _, B1 = first_existing_array(text, ["TD3_B1"])
        _, W2 = first_existing_array(text, ["TD3_W2"])
        _, B2 = first_existing_array(text, ["TD3_B2"])
        actions = []

    else:
        raise RuntimeError(f"Unknown net_type: {net_type}")

    for name, arr in {
        "W0": W0, "B0": B0,
        "W1": W1, "B1": B1,
        "W2": W2, "B2": B2,
    }.items():
        if arr is None:
            raise RuntimeError(f"{path}: missing {name} for {net_type}")

    return HeaderNetwork(
        net_type=net_type,
        obs_dim=obs_dim,
        h1=h1,
        h2=h2,
        out_dim=out_dim,
        activation=activation,
        pwm_limit=pwm_limit,
        W0=W0, B0=B0, W1=W1, B1=B1, W2=W2, B2=B2,
        actions=[int(x) for x in actions],
    )


class RipManager(Node):
    def __init__(self):
        super().__init__("rip_manager")

        self.raw_pub = self.create_publisher(String, "/rip/raw_cmd", 10)
        self.cmd_sub = self.create_subscription(String, "/rip/manager_cmd", self.manager_cmd_callback, 10)

        self.queue = deque()

        self.declare_parameter("auto_configure", False)
        self.declare_parameter("auto_download_networks", False)

        self.declare_parameter("stable_alg", "LQR")
        self.declare_parameter("observer_mode", "LUEN")
        self.declare_parameter("pwm_max", 150)

        self.declare_parameter("catch_alpha_deg", 15.0)
        self.declare_parameter("catch_alpha_dot", 8.0)
        self.declare_parameter("exit_alpha_deg", 25.0)
        self.declare_parameter("safe_alpha_deg", 60.0)
        self.declare_parameter("min_swing_steps", 40)

        self.declare_parameter("pref", 3120)
        self.declare_parameter("pdown", 996)
        self.declare_parameter("eref", 10000)
        self.declare_parameter("theta_cal", 6.503)
        self.declare_parameter("pot_cw", 1)
        self.declare_parameter("theta_sign", 1.0)
        self.declare_parameter("motor_sign", 1.0)

        self.declare_parameter("lqr_k", [-27.4273, -39.1200, -679.6201, -66.9800])
        self.declare_parameter("mpc_k", [-27.4242117, -39.0996784, -678.9152213, -66.9507566])
        self.declare_parameter("ref", [0.0, 0.0, 0.0, 0.0])

        self.declare_parameter("diff_alpha", 0.25)
        self.declare_parameter("observer_beta", 0.20)
        self.declare_parameter("obs_clip_theta", 500.0)
        self.declare_parameter("obs_clip_alpha", 500.0)

        model_dir = str(Path.home() / "rip_ros2_ws/src/rip_manager/models")
        self.declare_parameter("swing_dqn_path", model_dir + "/dqn_model_weights.h")
        self.declare_parameter("stable_dqn_path", model_dir + "/dqn_model_weights.h")
        self.declare_parameter("ppo_path", model_dir + "/ppo_model_weights.h")
        self.declare_parameter("td3_path", model_dir + "/td3_model_weights.h")

        self.started = False
        self.send_timer = self.create_timer(0.015, self.send_one)
        self.start_timer = self.create_timer(1.0, self.startup_once)

        self.get_logger().info("RIP Manager V2 started. Waiting for /rip/manager_cmd.")

    def p(self, name):
        return self.get_parameter(name).value

    def enqueue(self, line):
        self.queue.append(line)

    def send_one(self):
        if not self.queue:
            return
        line = self.queue.popleft()
        msg = String()
        msg.data = line
        self.raw_pub.publish(msg)

    def startup_once(self):
        if self.started:
            return
        self.started = True

        if self.p("auto_configure"):
            self.queue_apply(
                str(self.p("stable_alg")),
                str(self.p("observer_mode")),
                int(self.p("pwm_max")),
            )

        if self.p("auto_download_networks"):
            self.get_logger().warn(
                "V8.3 uses models compiled into flash; network download is disabled."
            )

        if self.queue:
            self.get_logger().info(f"Startup queued {len(self.queue)} commands.")

    def manager_cmd_callback(self, msg):
        text = msg.data.strip()
        if not text:
            return

        parts = [x.strip() for x in text.split(",")]
        cmd = parts[0].upper()

        try:
            if cmd == "APPLY":
                alg = parts[1].upper() if len(parts) > 1 else str(self.p("stable_alg")).upper()
                obs = parts[2].upper() if len(parts) > 2 else str(self.p("observer_mode")).upper()
                pwm = int(float(parts[3])) if len(parts) > 3 else int(self.p("pwm_max"))
                self.queue_apply(alg, obs, pwm)
                self.get_logger().info(f"Queued APPLY alg={alg}, obs={obs}, pwm={pwm}")

            elif cmd in {"DOWNLOAD_ALL", "DOWNLOAD_SWING", "DOWNLOAD_STABLE"}:
                self.get_logger().warn(
                    "V8.3 uses models compiled into flash; network download is disabled."
                )

            elif cmd == "STATUS":
                self.enqueue("STATUS")

            elif cmd == "STOP":
                self.enqueue("S")

            else:
                self.get_logger().warn(f"Unknown manager command: {text}")

        except Exception as e:
            self.get_logger().error(f"manager_cmd failed: {text}, error={e}")

    def queue_apply(self, alg, obs, pwm):
        alg = alg.upper()
        obs = obs.upper()

        self.enqueue("S")

        self.enqueue(f"PWM_MAX,{pwm}")
        self.enqueue(f"CATCH,{float(self.p('catch_alpha_deg'))},{float(self.p('catch_alpha_dot'))}")
        self.enqueue(f"EXIT,{float(self.p('exit_alpha_deg'))}")
        self.enqueue(f"SAFE,{float(self.p('safe_alpha_deg'))}")
        self.enqueue(f"MIN_SWING_STEPS,{int(self.p('min_swing_steps'))}")

        self.enqueue(f"PREF,{int(self.p('pref'))}")
        self.enqueue(f"PDOWN,{int(self.p('pdown'))}")
        self.enqueue(f"EREF,{int(self.p('eref'))}")
        self.enqueue(f"THETA_CAL,{float(self.p('theta_cal'))}")
        self.enqueue(f"POT_CW,{int(self.p('pot_cw'))}")
        self.enqueue(f"THETA_SIGN,{float(self.p('theta_sign'))}")
        self.enqueue(f"MOTOR_SIGN,{float(self.p('motor_sign'))}")

        self.queue_observer(obs)

        lqr_k = list(self.p("lqr_k"))
        mpc_k = list(self.p("mpc_k"))
        ref = list(self.p("ref"))

        self.enqueue("K,LQR," + ",".join(f"{x:.8g}" for x in lqr_k))
        self.enqueue("K,MPC," + ",".join(f"{x:.8g}" for x in mpc_k))
        self.enqueue("REF," + ",".join(f"{x:.8g}" for x in ref))

        self.enqueue(f"STAB,{alg}")
        self.enqueue("STATUS")

    def queue_observer(self, obs):
        obs = obs.upper()
        diff_alpha = float(self.p("diff_alpha"))
        clip_theta = float(self.p("obs_clip_theta"))
        clip_alpha = float(self.p("obs_clip_alpha"))

        # DIFF 仍然保留，用于最简单排查
        if obs == "DIFF":
            self.enqueue("OBS,DIFF")
            self.enqueue(f"DIFF,{diff_alpha:.8g}")
            self.enqueue(f"OBS_CLIP,{clip_theta:.8g},{clip_alpha:.8g}")
            return

        # 当前项目实际使用的是 Luenberger 形式：
        # xhat[k+1] = OBS_A*xhat[k] + OBS_BU*u[k] + OBS_BY*y[k]
        # 参数来自 mpc_linear_control.ino
        if obs in ["LUEN", "LUENBERGER"]:
            self.enqueue("OBS,LUEN")
        elif obs == "KALMAN":
            # 暂时也用同一套固定增益观测器矩阵，避免走临时 fallback
            self.enqueue("OBS,KALMAN")
        else:
            self.get_logger().warn(f"Bad observer={obs}; fallback to LUEN.")
            self.enqueue("OBS,LUEN")

        OBS_A = [
             0.82469568,  0.00438721, -0.31915638, -0.00085553,
            -1.75095359,  0.94056709, -0.04181246,  0.00193564,
            -0.05215683,  0.00005656,  0.76549687,  0.00439733,
            -1.38405407,  0.07685667, -15.83946960, 0.95027468,
        ]

        OBS_BU = [
             0.00001119,
             0.00396389,
            -0.00001398,
            -0.00583846,
        ]

        OBS_BY = [
             0.17530432,   0.31833008,
             1.75095359,  -0.19974721,
             0.05215683,   0.23646539,
             1.38405407,  16.66931771,
        ]

        self.enqueue("OBS_A," + ",".join(f"{x:.8g}" for x in OBS_A))
        self.enqueue("OBS_BU," + ",".join(f"{x:.8g}" for x in OBS_BU))
        self.enqueue("OBS_BY," + ",".join(f"{x:.8g}" for x in OBS_BY))
        self.enqueue(f"OBS_CLIP,{clip_theta:.8g},{clip_alpha:.8g}")

    def queue_download_all(self):
        self.queue_download_swing()
        self.queue_download_stable("DQN")
        self.queue_download_stable("PPO")
        self.queue_download_stable("TD3")
        self.enqueue("STATUS")

    def queue_download_swing(self):
        path = str(self.p("swing_dqn_path"))
        net = load_header_network(path, "DQN")
        self.queue_network(0, net)

    def queue_download_stable(self, alg):
        alg = alg.upper()
        if alg == "DQN":
            net = load_header_network(str(self.p("stable_dqn_path")), "DQN")
            self.queue_network(1, net)
        elif alg == "PPO":
            net = load_header_network(str(self.p("ppo_path")), "PPO")
            self.queue_network(2, net)
        elif alg == "TD3":
            net = load_header_network(str(self.p("td3_path")), "TD3")
            self.queue_network(3, net)
        else:
            self.get_logger().info(f"{alg} does not need network download.")

    def queue_network(self, slot, net):
        self.enqueue(
            f"NN_BEGIN,{slot},{net.net_type},{net.obs_dim},{net.h1},{net.h2},"
            f"{net.out_dim},{net.activation},{net.pwm_limit:.8g}"
        )

        if net.net_type == "DQN":
            actions = net.actions[:net.out_dim]
            self.enqueue(f"NN_ACTIONS,{slot}," + ",".join(str(int(x)) for x in actions))

        self.queue_array(slot, "W0", net.W0)
        self.queue_array(slot, "B0", net.B0)
        self.queue_array(slot, "W1", net.W1)
        self.queue_array(slot, "B1", net.B1)
        self.queue_array(slot, "W2", net.W2)
        self.queue_array(slot, "B2", net.B2)

        self.enqueue(f"NN_END,{slot}")

    def queue_array(self, slot, name, arr, chunk=16):
        for start in range(0, len(arr), chunk):
            part = arr[start:start + chunk]
            self.enqueue(
                f"NN_SET,{slot},{name},{start},"
                + ",".join(f"{float(x):.8g}" for x in part)
            )


def main(args=None):
    rclpy.init(args=args)
    node = RipManager()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
