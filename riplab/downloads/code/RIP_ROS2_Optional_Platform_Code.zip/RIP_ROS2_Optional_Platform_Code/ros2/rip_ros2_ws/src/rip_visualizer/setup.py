from setuptools import setup

package_name = 'rip_visualizer'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Zhixiang Ju',
    maintainer_email='zhixiangju@users.noreply.github.com',
    description='PyQt and Matplotlib ground station for the RIP ROS 2 example.',
    license='LicenseRef-Pending',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'visualizer_node = rip_visualizer.visualizer_node:main',
        ],
    },
)
