from setuptools import setup

package_name = 'rip_manager'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name,
            ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Zhixiang Ju',
    maintainer_email='zhixiangju@users.noreply.github.com',
    description='RIP manager for parameter, observer, controller and network download.',
    license='LicenseRef-Pending',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'manager_node = rip_manager.manager_node:main',
        ],
    },
)
