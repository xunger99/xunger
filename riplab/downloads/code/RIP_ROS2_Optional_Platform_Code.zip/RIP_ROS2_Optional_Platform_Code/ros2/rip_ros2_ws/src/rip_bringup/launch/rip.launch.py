from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    port_arg = DeclareLaunchArgument(
        'port',
        default_value='/dev/ttyACM0',
        description='STM32 serial port'
    )

    baud_arg = DeclareLaunchArgument(
        'baud',
        default_value='921600',
        description='Serial baudrate'
    )

    serial_bridge = Node(
        package='rip_serial_bridge',
        executable='serial_bridge_node',
        name='rip_serial_bridge',
        output='screen',
        parameters=[
            {
                'port': LaunchConfiguration('port'),
                'baud': LaunchConfiguration('baud')
            }
        ]
    )

    manager = Node(
        package='rip_manager',
        executable='manager_node',
        name='rip_manager',
        output='screen',
        parameters=[
            {
                'auto_configure': False,
                'auto_download_networks': False,
                'stable_alg': 'LQR',
                'observer_mode': 'LUEN',
                'pwm_max': 150
            }
        ]
    )

    visualizer = Node(
        package='rip_visualizer',
        executable='visualizer_node',
        name='rip_visualizer',
        output='screen'
    )

    return LaunchDescription([
        port_arg,
        baud_arg,
        serial_bridge,
        manager,
        visualizer
    ])
