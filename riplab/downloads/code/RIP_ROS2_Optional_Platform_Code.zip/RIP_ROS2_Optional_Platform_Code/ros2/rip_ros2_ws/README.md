# RIP ROS 2 Workspace

This is a source-only colcon workspace for the optional RIP multi-controller
framework. See the parent [ROS 2 guide](../README.md) before using it with the
physical apparatus.

Build on Ubuntu 24.04 with ROS 2 Jazzy:

```bash
source /opt/ros/jazzy/setup.bash
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

Launch all nodes:

```bash
ros2 launch rip_bringup rip.launch.py port:=/dev/ttyACM0 baud:=921600
```

The generated `build/`, `install/`, and `log/` directories are local build
products and must not be committed.
