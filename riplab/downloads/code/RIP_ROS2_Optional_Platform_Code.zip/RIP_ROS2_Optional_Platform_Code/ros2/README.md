# ROS 2 Multi-Controller Framework Example

This directory contains a minimal ROS 2 framework for selecting and monitoring
different controllers on the rotary inverted pendulum (RIP) hardware.

> [!IMPORTANT]
> This is an optional integration example. It does not replace the
> algorithm-specific Python simulations, reinforcement-learning training code,
> hardware deployment panels, firmware, or laboratory manuals in the rest of
> this repository. Use those packages to learn, train, validate, and deploy each
> controller independently.

The supplied V8.3 firmware exposes five selectable profiles: LQR, MPC, DQN,
PPO, and TD3. Dual-loop PID is not included in this profile selector. The
real-time 200 Hz sensor and control loop remains on the STM32. ROS 2 provides
configuration, profile selection, serial transport, state publication, and a
basic visualization panel.

## Directory Layout

```text
ros2/
|-- README.md
|-- UTM_UBUNTU_SETUP.md
|-- firmware/
|   `-- rosrip_v8_3/
|       |-- rosrip_v8_3.ino
|       |-- rip_models_v81.h
|       `-- README.md
`-- rip_ros2_ws/
    |-- README.md
    `-- src/
        |-- rip_bringup/
        |-- rip_interfaces/
        |-- rip_manager/
        |-- rip_serial_bridge/
        `-- rip_visualizer/
```

Only source files are versioned. The original archive's machine-specific
`build/`, `install/`, `log/`, backup, cache, and macOS metadata files are
intentionally excluded.

## System Architecture

```text
PyQt ground station
  |  /rip/manager_cmd and /rip/raw_cmd
  v
ROS 2 manager -> serial bridge -> STM32 V8.3 firmware -> motor and sensors
                                      |
                                      v
                         /rip/state -> visualization
```

The packages have the following roles:

| Package | Role |
| --- | --- |
| `rip_interfaces` | Defines command and telemetry messages. |
| `rip_serial_bridge` | Converts ROS 2 topics to the STM32 serial protocol and publishes parsed telemetry. |
| `rip_manager` | Provides an optional higher-level command queue for advanced configuration. |
| `rip_visualizer` | Provides controller selection, calibration, GO/STOP, 3D visualization, and result plots. |
| `rip_bringup` | Starts the bridge, manager, and visualizer together. |

## What Each Firmware Profile Does

| Profile | V8.3 firmware behavior |
| --- | --- |
| LQR | Fixed pre-swing, swing DQN away from upright, then observer-based LQR with soft blending. |
| MPC | Fixed pre-swing, swing DQN away from upright, then observer-based MPC with soft blending. |
| DQN | Pure DQN profile for swing-up and balance after the initial pre-swing sequence. |
| PPO | Fixed pre-swing, swing DQN away from upright, then PPO near upright. |
| TD3 | TD3 profile using the previous applied action in its observation after the initial pre-swing sequence. |

The neural-network assets are compiled into `rip_models_v81.h` and stored in
STM32 flash. V8.3 intentionally disables serial network downloads.

## Supported Host Setup

The recommended new setup is Ubuntu 24.04 with ROS 2 Jazzy. Both ARM64 and
AMD64 are supported by ROS 2 Jazzy on Ubuntu 24.04. Mac users can run this in
UTM; follow [UTM_UBUNTU_SETUP.md](UTM_UBUNTU_SETUP.md).

The source archive contained build products from a Python 3.8 environment,
which is consistent with an older Ubuntu/ROS 2 installation. Those build
products are not portable and are not included here. Always rebuild from
`src/` on the target Ubuntu system.

## Build the Workspace

Inside Ubuntu:

```bash
source /opt/ros/jazzy/setup.bash
cd <repository>/ros2/rip_ros2_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

Do not copy `build/`, `install/`, or `log/` from another computer. Colcon will
generate them locally.

## Prepare the STM32

1. Keep `rosrip_v8_3.ino` and `rip_models_v81.h` in the same Arduino sketch
   directory.
2. Open `rosrip_v8_3.ino` in Arduino IDE.
3. Select the course STM32 target (`Nucleo-64` / STM32F446RE) and the same
   upload method used by the other laboratory firmware.
4. Compile and upload the sketch.
5. Close Arduino Serial Monitor before starting the ROS 2 serial bridge.

See [firmware/rosrip_v8_3/README.md](firmware/rosrip_v8_3/README.md) for the
firmware-specific notes.

## Start the Framework

Attach the STM32 USB serial device to Ubuntu and find its device name:

```bash
ls -l /dev/ttyACM* /dev/ttyUSB* 2>/dev/null
```

Launch all nodes, replacing the port when necessary:

```bash
cd <repository>/ros2/rip_ros2_ws
source /opt/ros/jazzy/setup.bash
source install/setup.bash
ros2 launch rip_bringup rip.launch.py port:=/dev/ttyACM0 baud:=921600
```

The panel should open and `/rip/state` should update. In another terminal:

```bash
source /opt/ros/jazzy/setup.bash
source <repository>/ros2/rip_ros2_ws/install/setup.bash
ros2 topic echo /rip/state
```

## Physical-System Workflow

1. Secure the apparatus, clear the complete arm sweep, and keep the external
   motor supply off while checking communication.
2. Hold the pendulum upright and record `PREF` with the upright calibration
   button.
3. Let the pendulum hang downward and record `PDOWN` with the downward
   calibration button.
4. Select LQR, MPC, DQN, PPO, or TD3 and begin with a conservative PWM limit.
5. Click `Apply Config`. The GUI sends one atomic `CONFIG` command containing
   the algorithm, PWM limit, `PREF`, and `PDOWN`.
6. Verify the displayed angles, signs, serial status, and emergency-stop path.
7. Clear the workspace, enable motor power, and click `GO`.
8. Click `STOP` immediately if motion, cabling, sensing, or control is abnormal.

The GUI sends `RUN,<algorithm>,<pwm>,<pref>,<pdown>`, so profile selection and
the safety-critical calibration values are applied atomically. The STM32
rejects a different profile while already armed; stop the current run before
switching algorithms.

## Useful ROS 2 Topics

| Topic | Type | Purpose |
| --- | --- | --- |
| `/rip/state` | `rip_interfaces/msg/RipState` | Parsed STM32 telemetry. |
| `/rip/raw_cmd` | `std_msgs/msg/String` | Raw serial command sent to the STM32. |
| `/rip/manager_cmd` | `std_msgs/msg/String` | Higher-level configuration request processed by `rip_manager`. |
| `/rip/cmd` | `rip_interfaces/msg/RipCommand` | Basic enable and emergency-stop interface. |

For diagnosis, controller profiles can be selected without the GUI:

```bash
ros2 topic pub --once /rip/raw_cmd std_msgs/msg/String "{data: 'STOP'}"
ros2 topic pub --once /rip/raw_cmd std_msgs/msg/String "{data: 'GO,LQR'}"
ros2 topic pub --once /rip/raw_cmd std_msgs/msg/String "{data: 'STATUS'}"
```

Do not use topic commands to bypass calibration or safety checks.

## Scope and Limitations

This example deliberately has a narrow scope:

- It does not train DQN, PPO, or TD3 models.
- It does not reproduce the standalone nonlinear simulations.
- It does not expose every parameter available in the algorithm-specific
  deployment panels.
- It does not replace the individual PID, LQR, MPC, DQN, PPO, or TD3 firmware
  used in the laboratory modules.
- It does not include a dual-loop PID selectable profile.
- It is not a complete `ros2_control` hardware interface or production robot
  safety system.
- ROS 2 and the GUI are not the real-time controller. The STM32 owns the 200 Hz
  control loop.
- The bundled model header is an example deployment snapshot. It must remain
  matched to the V8.3 firmware architecture and observation definitions.

Use the rest of the repository for algorithm derivation, simulation, training,
model validation, dedicated hardware deployment, and experimental reporting.

## Troubleshooting

### No serial device

Confirm that the STM32 is attached to the Ubuntu guest rather than macOS, then
check membership in the `dialout` group. Close Arduino Serial Monitor and any
other program using the port.

### The GUI opens but no state arrives

Check the launch port, firmware baud rate (`921600`), firmware version, and the
serial bridge log. V8.3 telemetry contains 17 data fields after the `LOG`
prefix.

### Network download commands fail

This is expected with V8.3. Models are compiled into flash; `NN_SET` download
commands are disabled. Select a profile with `GO,LQR`, `GO,MPC`, `GO,DQN`,
`GO,PPO`, or `GO,TD3`.

### A different controller will not start

Send `STOP`, wait until the firmware reports that it is disarmed, then start
the new profile.

## License

The repository release license is pending supervisor approval. See the root
`LICENSE_PENDING.txt`.
