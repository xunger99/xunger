# Reinforcement Learning

This folder contains the DQN, PPO, and TD3 modules.

- `training/`: simulation training packages.
- `deployment/`: Python simulation tests, Python hardware deployment scripts, firmware, and TD3 extra compatibility checks.

Generated runs, checkpoints, logs, and caches are intentionally excluded from version control.

